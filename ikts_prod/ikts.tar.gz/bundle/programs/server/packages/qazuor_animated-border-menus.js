(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function () {

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/qazuor:animated-border-menus/qazuor:animated-border-menu //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
// Write your package code here!                                     // 1
                                                                     // 2
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['qazuor:animated-border-menus'] = {};

})();

//# sourceMappingURL=qazuor_animated-border-menus.js.map
